import hashlib, secrets
from datetime import datetime, timedelta, timezone
import bcrypt
from jose import jwt, JWTError
from .config import settings


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        return False

def create_access_token(user_id: int, role: str) -> tuple[str, str, datetime]:
    jti = secrets.token_urlsafe(18)
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.access_token_expire_minutes)
    token = jwt.encode({"sub": str(user_id), "role": role, "jti": jti, "exp": exp}, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)
    return token, jti, exp.replace(tzinfo=None)

def decode_access_token(token: str):
    return jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])

def make_reset_token() -> str:
    return secrets.token_urlsafe(32)

def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()
