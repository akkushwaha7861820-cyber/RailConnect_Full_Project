from datetime import date, datetime, timezone
from typing import Optional
from sqlmodel import SQLModel, Field
from sqlalchemy import UniqueConstraint


def utcnow() -> datetime:
    return datetime.now(timezone.utc)

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    email: str = Field(index=True, unique=True, max_length=255)
    full_name: str = Field(max_length=120)
    password_hash: str
    role: str = Field(default="passenger", index=True)
    is_active: bool = True
    created_at: datetime = Field(default_factory=utcnow)

class Station(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    code: str = Field(index=True, unique=True, max_length=10)
    name: str = Field(index=True, max_length=120)
    city: str = Field(max_length=120)

class Train(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    train_number: str = Field(index=True, unique=True, max_length=20)
    name: str = Field(max_length=120)
    source_station_id: int = Field(foreign_key="station.id", index=True)
    destination_station_id: int = Field(foreign_key="station.id", index=True)
    departure_time: str = Field(max_length=5)
    arrival_time: str = Field(max_length=5)
    fare: float = Field(ge=0)
    total_seats: int = Field(gt=0)
    is_active: bool = True

class JourneyInventory(SQLModel, table=True):
    __tablename__ = "journey_inventory"
    id: Optional[int] = Field(default=None, primary_key=True)
    train_id: int = Field(foreign_key="train.id", index=True)
    journey_date: date = Field(index=True)
    available_seats: int = Field(ge=0)
    __table_args__ = (UniqueConstraint("train_id", "journey_date", name="uq_inventory_train_date"), {"sqlite_autoincrement": True})

class Booking(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    pnr: str = Field(index=True, unique=True, max_length=20)
    user_id: int = Field(foreign_key="user.id", index=True)
    train_id: int = Field(foreign_key="train.id", index=True)
    journey_date: date = Field(index=True)
    passenger_name: str = Field(max_length=120)
    seats: int = Field(gt=0)
    total_fare: float = Field(ge=0)
    status: str = Field(default="CONFIRMED", index=True)
    payment_status: str = "SIMULATED_PAID"
    created_at: datetime = Field(default_factory=utcnow)
    cancelled_at: Optional[datetime] = None

class ResetToken(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id", index=True)
    token_hash: str = Field(index=True, unique=True)
    expires_at: datetime
    used: bool = False

class RevokedToken(SQLModel, table=True):
    jti: str = Field(primary_key=True)
    expires_at: datetime
