from sqlmodel import Session, select
from .database import engine
from .models import Station, Train, User
from .config import settings
from .security import hash_password

def seed_demo_data():
    with Session(engine) as s:
        stations = {}
        for code, name, city in [("NDLS", "New Delhi", "New Delhi"), ("CNB", "Kanpur Central", "Kanpur"), ("GZB", "Ghaziabad", "Ghaziabad"), ("LKO", "Lucknow NR", "Lucknow")]:
            station = s.exec(select(Station).where(Station.code == code)).first()
            if not station:
                station = Station(code=code, name=name, city=city); s.add(station); s.flush()
            stations[code] = station
        if not s.exec(select(Train).where(Train.train_number == "RC1201")).first():
            s.add(Train(train_number="RC1201", name="RailConnect Intercity", source_station_id=stations["NDLS"].id, destination_station_id=stations["CNB"].id, departure_time="08:10", arrival_time="13:25", fare=450.0, total_seats=120, is_active=True))
        if not s.exec(select(Train).where(Train.train_number == "RC1202")).first():
            s.add(Train(train_number="RC1202", name="Ganga Express Demo", source_station_id=stations["GZB"].id, destination_station_id=stations["LKO"].id, departure_time="09:30", arrival_time="15:45", fare=520.0, total_seats=80, is_active=True))
        admin = s.exec(select(User).where(User.email == settings.admin_email.lower())).first()
        if not admin:
            s.add(User(email=settings.admin_email.lower(), full_name="RailConnect Admin", password_hash=hash_password(settings.admin_password), role="admin"))
        s.commit()
