from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
import secrets
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from pathlib import Path
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlmodel import Session, select
from sqlalchemy import update, text
from jose import JWTError
from .config import settings
from .database import create_db_and_tables, get_session, engine
from .models import User, Station, Train, JourneyInventory, Booking, ResetToken, RevokedToken
from .schemas import SignupIn, LoginIn, UserOut, TokenOut, ForgotPasswordIn, ResetPasswordIn, StationIn, TrainIn, BookingIn
from .security import hash_password, verify_password, create_access_token, decode_access_token, make_reset_token, token_hash
from .seed import seed_demo_data

@asynccontextmanager
async def lifespan(app: FastAPI):
    create_db_and_tables()
    if settings.seed_demo_data:
        seed_demo_data()
    yield

app = FastAPI(title=settings.app_name, version="1.0.0", description="Fictional railway booking backend. No real railway or payment integration.", lifespan=lifespan)
bearer = HTTPBearer(auto_error=False)


def get_current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer), session: Session = Depends(get_session)) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        payload = decode_access_token(credentials.credentials)
        user_id = int(payload.get("sub", "")); jti = payload.get("jti")
        if not jti:
            raise ValueError("Missing token ID")
    except (JWTError, ValueError, TypeError):
        raise HTTPException(status_code=401, detail="Invalid or expired access token")
    if session.get(RevokedToken, jti):
        raise HTTPException(status_code=401, detail="Token has been revoked; please log in again")
    user = session.get(User, user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User account is unavailable")
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required")
    return user


def station_names(session: Session, train: Train):
    src = session.get(Station, train.source_station_id)
    dst = session.get(Station, train.destination_station_id)
    return src, dst


def ensure_inventory(session: Session, train: Train, journey_date: date):
    # INSERT OR IGNORE plus a unique (train_id, journey_date) key prevents two first-time
    # searches/bookings from creating duplicate inventory rows for the same journey.
    session.exec(text("INSERT OR IGNORE INTO journey_inventory (train_id, journey_date, available_seats) VALUES (:tid, :jdate, :seats)"), params={"tid": train.id, "jdate": journey_date.isoformat(), "seats": train.total_seats})
    session.flush()
    return session.exec(select(JourneyInventory).where(JourneyInventory.train_id == train.id, JourneyInventory.journey_date == journey_date)).first()

@app.get("/", response_class=HTMLResponse, tags=["system"])
def root():
    return (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/demo", response_class=HTMLResponse, tags=["system"])
def demo_page():
    return (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/health", tags=["system"])
def health():
    return {"status": "ok"}

@app.post("/auth/signup", response_model=UserOut, status_code=201, tags=["authentication"])
def signup(data: SignupIn, session: Session = Depends(get_session)):
    email = str(data.email).lower()
    if session.exec(select(User).where(User.email == email)).first():
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = User(email=email, full_name=data.full_name.strip(), password_hash=hash_password(data.password), role="passenger")
    session.add(user); session.commit(); session.refresh(user)
    return user

@app.post("/auth/login", response_model=TokenOut, tags=["authentication"])
def login(data: LoginIn, session: Session = Depends(get_session)):
    user = session.exec(select(User).where(User.email == str(data.email).lower())).first()
    if not user or not user.is_active or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    token, _, _ = create_access_token(user.id, user.role)
    return TokenOut(access_token=token)

@app.post("/auth/logout", tags=["authentication"])
def logout(user: User = Depends(get_current_user), credentials: HTTPAuthorizationCredentials | None = Depends(bearer), session: Session = Depends(get_session)):
    try:
        payload = decode_access_token(credentials.credentials)
        jti = payload["jti"]
        exp = datetime.fromtimestamp(payload["exp"], timezone.utc).replace(tzinfo=None)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")
    if not session.get(RevokedToken, jti):
        session.add(RevokedToken(jti=jti, expires_at=exp)); session.commit()
    return {"message": "Logged out successfully. This access token has been revoked."}

@app.get("/users/me", response_model=UserOut, tags=["users"])
def my_profile(user: User = Depends(get_current_user)):
    return user

@app.post("/auth/forgot-password", tags=["authentication"])
def forgot_password(data: ForgotPasswordIn, session: Session = Depends(get_session)):
    user = session.exec(select(User).where(User.email == str(data.email).lower(), User.is_active == True)).first()
    # Same public response whether or not the account exists, to avoid account enumeration.
    response = {"message": "If the account exists, a reset token has been generated."}
    if user:
        raw = make_reset_token()
        session.add(ResetToken(user_id=user.id, token_hash=token_hash(raw), expires_at=datetime.utcnow() + timedelta(minutes=settings.reset_token_expire_minutes), used=False))
        session.commit()
        # Development simulation only. In production send by email and never return the token.
        response["development_reset_token"] = raw
        response["note"] = "Development-only email simulation; token expires and can be used once."
    return response

@app.post("/auth/reset-password", tags=["authentication"])
def reset_password(data: ResetPasswordIn, session: Session = Depends(get_session)):
    item = session.exec(select(ResetToken).where(ResetToken.token_hash == token_hash(data.token))).first()
    if not item or item.used or item.expires_at <= datetime.utcnow():
        raise HTTPException(status_code=400, detail="Reset token is invalid, expired, or already used")
    user = session.get(User, item.user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=400, detail="Reset token is invalid")
    # Claim the token with a conditional update in the same transaction as the password change.
    # Concurrent requests cannot both consume the same reset token successfully.
    claimed = session.exec(update(ResetToken).where(ResetToken.id == item.id, ResetToken.used == False, ResetToken.expires_at > datetime.utcnow()).values(used=True))
    if claimed.rowcount != 1:
        session.rollback()
        raise HTTPException(status_code=400, detail="Reset token is invalid, expired, or already used")
    user.password_hash = hash_password(data.new_password)
    session.add(user); session.commit()
    return {"message": "Password reset successfully. The reset token cannot be reused."}

@app.get("/stations", tags=["railway data"])
def list_stations(session: Session = Depends(get_session)):
    return session.exec(select(Station).order_by(Station.name)).all()

@app.post("/admin/stations", status_code=201, tags=["admin"], dependencies=[Depends(require_admin)])
def add_station(data: StationIn, session: Session = Depends(get_session)):
    code = data.code.strip().upper()
    if session.exec(select(Station).where(Station.code == code)).first():
        raise HTTPException(status_code=409, detail="Station code already exists")
    station = Station(code=code, name=data.name.strip(), city=data.city.strip())
    session.add(station); session.commit(); session.refresh(station); return station

@app.post("/admin/trains", status_code=201, tags=["admin"], dependencies=[Depends(require_admin)])
def add_train(data: TrainIn, session: Session = Depends(get_session)):
    if data.source_station_id == data.destination_station_id:
        raise HTTPException(status_code=422, detail="Origin and destination stations must differ")
    if not session.get(Station, data.source_station_id) or not session.get(Station, data.destination_station_id):
        raise HTTPException(status_code=404, detail="Source or destination station not found")
    if session.exec(select(Train).where(Train.train_number == data.train_number)).first():
        raise HTTPException(status_code=409, detail="Train number already exists")
    train = Train(**data.model_dump()); session.add(train); session.commit(); session.refresh(train); return train

@app.get("/admin/trains", tags=["admin"], dependencies=[Depends(require_admin)])
def admin_list_trains(session: Session = Depends(get_session)):
    return session.exec(select(Train).order_by(Train.train_number)).all()

@app.patch("/admin/trains/{train_id}", tags=["admin"], dependencies=[Depends(require_admin)])
def update_train(train_id: int, data: TrainIn, session: Session = Depends(get_session)):
    train = session.get(Train, train_id)
    if not train: raise HTTPException(status_code=404, detail="Train not found")
    if data.source_station_id == data.destination_station_id: raise HTTPException(status_code=422, detail="Origin and destination stations must differ")
    if not session.get(Station, data.source_station_id) or not session.get(Station, data.destination_station_id): raise HTTPException(status_code=404, detail="Source or destination station not found")
    duplicate = session.exec(select(Train).where(Train.train_number == data.train_number, Train.id != train_id)).first()
    if duplicate: raise HTTPException(status_code=409, detail="Train number already exists")
    old_seats = train.total_seats
    for key, value in data.model_dump().items(): setattr(train, key, value)
    session.add(train); session.commit(); session.refresh(train)
    # Existing journey inventory remains as-is, so already-sold seats are never accidentally recreated.
    return train

@app.post("/admin/trains/{train_id}/deactivate", tags=["admin"], dependencies=[Depends(require_admin)])
def deactivate_train(train_id: int, session: Session = Depends(get_session)):
    train = session.get(Train, train_id)
    if not train: raise HTTPException(status_code=404, detail="Train not found")
    train.is_active = False; session.add(train); session.commit()
    return {"message": "Train deactivated", "train_id": train_id}

@app.get("/trains/search", tags=["trains"])
def search_trains(source: str, destination: str, journey_date: date, session: Session = Depends(get_session)):
    if journey_date < date.today(): raise HTTPException(status_code=422, detail="Journey date cannot be in the past")
    src_code, dst_code = source.strip().upper(), destination.strip().upper()
    src = session.exec(select(Station).where((Station.code == src_code) | (Station.name.ilike(src_code)) | (Station.city.ilike(src_code)))).first()
    dst = session.exec(select(Station).where((Station.code == dst_code) | (Station.name.ilike(dst_code)) | (Station.city.ilike(dst_code)))).first()
    if not src or not dst: raise HTTPException(status_code=404, detail="Source or destination station not found")
    if src.id == dst.id: raise HTTPException(status_code=422, detail="Source and destination must be different")
    trains = session.exec(select(Train).where(Train.source_station_id == src.id, Train.destination_station_id == dst.id, Train.is_active == True)).all()
    results = []
    for train in trains:
        inventory = ensure_inventory(session, train, journey_date)
        results.append({"train_id": train.id, "train_number": train.train_number, "name": train.name, "source": src.name, "destination": dst.name, "departure_time": train.departure_time, "arrival_time": train.arrival_time, "fare_per_seat": train.fare, "total_seats": train.total_seats, "available_seats": inventory.available_seats, "journey_date": journey_date})
    session.commit()
    return {"count": len(results), "trains": results, "message": None if results else "No trains match this route and date"}

@app.post("/bookings", status_code=201, tags=["bookings"])
def book_ticket(data: BookingIn, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    if data.journey_date < date.today(): raise HTTPException(status_code=422, detail="Journey date cannot be in the past")
    train = session.get(Train, data.train_id)
    if not train or not train.is_active: raise HTTPException(status_code=404, detail="Active train not found")
    try:
        # Inventory creation is idempotent. The conditional UPDATE is the key concurrency guard:
        # only one transaction can decrement a given inventory row while enough seats remain.
        inventory = ensure_inventory(session, train, data.journey_date)
        session.commit()
        result = session.exec(update(JourneyInventory).where(JourneyInventory.id == inventory.id, JourneyInventory.available_seats >= data.seats).values(available_seats=JourneyInventory.available_seats - data.seats))
        if result.rowcount != 1:
            session.rollback()
            inv = session.exec(select(JourneyInventory).where(JourneyInventory.train_id == train.id, JourneyInventory.journey_date == data.journey_date)).first()
            available = inv.available_seats if inv else train.total_seats
            raise HTTPException(status_code=409, detail=f"Not enough seats available. Currently available: {available}")
        pnr = "RC" + secrets.token_hex(5).upper()
        booking = Booking(pnr=pnr, user_id=user.id, train_id=train.id, journey_date=data.journey_date, passenger_name=data.passenger_name.strip(), seats=data.seats, total_fare=round(train.fare * data.seats, 2), status="CONFIRMED", payment_status="SIMULATED_PAID")
        session.add(booking); session.commit(); session.refresh(booking)
        return booking
    except HTTPException:
        raise
    except Exception:
        session.rollback()
        raise HTTPException(status_code=500, detail="Booking could not be completed; no seats were intentionally reserved")

@app.get("/bookings", tags=["bookings"])
def my_bookings(user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    return session.exec(select(Booking).where(Booking.user_id == user.id).order_by(Booking.created_at.desc())).all()

@app.get("/bookings/{pnr}", tags=["bookings"])
def get_booking(pnr: str, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    booking = session.exec(select(Booking).where(Booking.pnr == pnr.upper(), Booking.user_id == user.id)).first()
    if not booking: raise HTTPException(status_code=404, detail="Booking not found")
    return booking

@app.post("/bookings/{pnr}/cancel", tags=["bookings"])
def cancel_booking(pnr: str, user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    booking = session.exec(select(Booking).where(Booking.pnr == pnr.upper(), Booking.user_id == user.id)).first()
    if not booking: raise HTTPException(status_code=404, detail="Booking not found")
    if booking.status != "CONFIRMED": raise HTTPException(status_code=409, detail="Only confirmed bookings can be cancelled; seats are not released twice")
    # Conditional status update prevents two cancellation requests from releasing the same seats twice.
    changed = session.exec(update(Booking).where(Booking.id == booking.id, Booking.status == "CONFIRMED").values(status="CANCELLED", cancelled_at=datetime.utcnow()))
    if changed.rowcount != 1:
        session.rollback(); raise HTTPException(status_code=409, detail="Booking has already been cancelled")
    inventory = session.exec(select(JourneyInventory).where(JourneyInventory.train_id == booking.train_id, JourneyInventory.journey_date == booking.journey_date)).first()
    if not inventory:
        session.rollback(); raise HTTPException(status_code=500, detail="Journey inventory missing; cancellation was not completed")
    session.exec(update(JourneyInventory).where(JourneyInventory.id == inventory.id).values(available_seats=JourneyInventory.available_seats + booking.seats))
    session.commit()
    return {"message": "Booking cancelled successfully", "pnr": booking.pnr, "status": "CANCELLED", "seats_released": booking.seats}

@app.get("/admin/inventory/{train_id}", tags=["admin"], dependencies=[Depends(require_admin)])
def get_inventory(train_id: int, journey_date: date, session: Session = Depends(get_session)):
    train = session.get(Train, train_id)
    if not train: raise HTTPException(status_code=404, detail="Train not found")
    inv = ensure_inventory(session, train, journey_date); session.commit()
    return {"train_id": train_id, "journey_date": journey_date, "total_seats": train.total_seats, "available_seats": inv.available_seats}
