from datetime import date
from typing import Optional
from pydantic import BaseModel, EmailStr, Field, field_validator

class SignupIn(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=120)
    password: str = Field(min_length=8, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    role: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ForgotPasswordIn(BaseModel):
    email: EmailStr

class ResetPasswordIn(BaseModel):
    token: str = Field(min_length=20)
    new_password: str = Field(min_length=8, max_length=128)

class StationIn(BaseModel):
    code: str = Field(min_length=2, max_length=10)
    name: str = Field(min_length=2, max_length=120)
    city: str = Field(min_length=2, max_length=120)

class TrainIn(BaseModel):
    train_number: str = Field(min_length=2, max_length=20)
    name: str = Field(min_length=2, max_length=120)
    source_station_id: int
    destination_station_id: int
    departure_time: str
    arrival_time: str
    fare: float = Field(ge=0)
    total_seats: int = Field(gt=0, le=10000)
    is_active: bool = True

    @field_validator("departure_time", "arrival_time")
    @classmethod
    def valid_time(cls, v):
        import re
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", v):
            raise ValueError("Time must use 24-hour HH:MM format")
        return v

class BookingIn(BaseModel):
    train_id: int
    journey_date: date
    passenger_name: str = Field(min_length=2, max_length=120)
    seats: int = Field(default=1, ge=1, le=6)

class BookingOut(BaseModel):
    id: int
    pnr: str
    train_id: int
    journey_date: date
    passenger_name: str
    seats: int
    total_fare: float
    status: str
    payment_status: str
