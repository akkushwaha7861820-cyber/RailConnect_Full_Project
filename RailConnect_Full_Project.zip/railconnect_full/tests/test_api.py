from datetime import date, timedelta
from fastapi.testclient import TestClient
from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy.pool import StaticPool
import pytest
from app.main import app
from app.database import get_session
from app.models import Station, Train, User, JourneyInventory
from app.security import hash_password

@pytest.fixture()
def client():
    test_engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    SQLModel.metadata.create_all(test_engine)
    with Session(test_engine) as s:
        nd = Station(code="NDLS", name="New Delhi", city="New Delhi")
        cn = Station(code="CNB", name="Kanpur Central", city="Kanpur")
        s.add(nd); s.add(cn); s.commit(); s.refresh(nd); s.refresh(cn)
        s.add(Train(train_number="T100", name="Test Express", source_station_id=nd.id, destination_station_id=cn.id, departure_time="08:00", arrival_time="13:00", fare=500, total_seats=2, is_active=True))
        s.add(User(email="admin@test.local", full_name="Admin", password_hash=hash_password("AdminPass123!"), role="admin"))
        s.commit()
    def override():
        with Session(test_engine) as s: yield s
    app.dependency_overrides[get_session] = override
    with TestClient(app) as c: yield c
    app.dependency_overrides.clear()

def signup_login(c, email="user@test.local"):
    r=c.post('/auth/signup',json={"email":email,"full_name":"Test User","password":"StrongPass123!"})
    assert r.status_code == 201
    r=c.post('/auth/login',json={"email":email,"password":"StrongPass123!"})
    assert r.status_code == 200
    return r.json()['access_token']

def test_signup_login_and_bad_login(client):
    token=signup_login(client)
    assert client.get('/users/me',headers={"Authorization":f"Bearer {token}"}).status_code==200
    assert client.post('/auth/login',json={"email":"user@test.local","password":"wrong-password"}).status_code==401

def test_admin_only_and_search(client):
    assert client.post('/admin/trains',json={"train_number":"X","name":"X","source_station_id":1,"destination_station_id":2,"departure_time":"08:00","arrival_time":"09:00","fare":100,"total_seats":5}).status_code==401
    r=client.get('/trains/search',params={"source":"NDLS","destination":"CNB","journey_date":str(date.today()+timedelta(days=2))})
    assert r.status_code==200 and r.json()['count']==1

def test_booking_cancel_and_no_double_release(client):
    token=signup_login(client); h={"Authorization":f"Bearer {token}"}; d=str(date.today()+timedelta(days=2))
    b=client.post('/bookings',headers=h,json={"train_id":1,"journey_date":d,"passenger_name":"Test User","seats":2})
    assert b.status_code==201
    pnr=b.json()['pnr']
    search=client.get('/trains/search',params={"source":"NDLS","destination":"CNB","journey_date":d}).json()
    assert search['trains'][0]['available_seats']==0
    assert client.post('/bookings',headers=h,json={"train_id":1,"journey_date":d,"passenger_name":"Another User","seats":1}).status_code==409
    assert client.post(f'/bookings/{pnr}/cancel',headers=h).status_code==200
    assert client.post(f'/bookings/{pnr}/cancel',headers=h).status_code==409
    search=client.get('/trains/search',params={"source":"NDLS","destination":"CNB","journey_date":d}).json()
    assert search['trains'][0]['available_seats']==2

def test_password_reset_one_time(client):
    signup_login(client)
    r=client.post('/auth/forgot-password',json={"email":"user@test.local"})
    assert r.status_code==200 and 'development_reset_token' in r.json()
    token=r.json()['development_reset_token']
    assert client.post('/auth/reset-password',json={"token":token,"new_password":"NewStrongPass123!"}).status_code==200
    assert client.post('/auth/reset-password',json={"token":token,"new_password":"OtherStrongPass123!"}).status_code==400
    assert client.post('/auth/login',json={"email":"user@test.local","password":"NewStrongPass123!"}).status_code==200
