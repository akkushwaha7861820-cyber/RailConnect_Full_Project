# RailConnect — Railway Booking Backend

A fictional mini railway reservation API built with **Python 3.11+, FastAPI, SQLModel, SQLite, Pydantic, bcrypt and JWT**. It includes a responsive interactive booking website at `/` (also available at `/demo`) and interactive API documentation at `/docs`. This project does not connect to IRCTC or process real payments.

## Features

- Passenger signup/login, bcrypt password hashing, JWT authentication and server-side logout token revocation.
- User profile and booking history scoped to the authenticated user.
- Forgot/reset password with expiring, one-use tokens. In development, the reset token is returned as a simulated email; never do this in production.
- Admin-only station and train creation, train updates, deactivation, and inventory inspection.
- Search by station code/name/city and journey date.
- PNR generation, simulated payment status, booking/cancellation, and seat inventory per train/date.
- Conditional database updates guard against overbooking and repeated cancellation seat release.
- Pytest API tests for authentication, unauthorized access, searching, full trains, cancellation and reset-token reuse.

## Setup (Windows 11 / VS Code)

1. Install Python 3.11+ and open this folder in VS Code.
2. In the terminal, create and activate a virtual environment:

   ```powershell
   py -3.11 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` for that terminal only, then activate again. Alternatively run `.venv\Scripts\python.exe` directly.
3. Install packages:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env`. Change `JWT_SECRET_KEY` to a long random secret and change `ADMIN_PASSWORD`. The defaults are for local demo only.
5. Start the API:

   ```powershell
   python -m uvicorn app.main:app --reload
   ```
6. Open:
   - Swagger UI: <http://127.0.0.1:8000/docs>
   - RailConnect website: <http://127.0.0.1:8000/>
   - Alternate website URL: <http://127.0.0.1:8000/demo>
   - Health: <http://127.0.0.1:8000/health>

SQLite database `railconnect.db` is created in the project directory. Fictional demo stations and trains plus a local admin account are seeded on startup when `SEED_DEMO_DATA=true`.

## Demo admin

Credentials are read from `.env` (`ADMIN_EMAIL`, `ADMIN_PASSWORD`). With the untouched example file, the local demo credentials are `admin@railconnect.local` / `ChangeMe123!`. **Change these before use or sharing.** Do not use demo credentials in production.

## Interactive website

Open `http://127.0.0.1:8000/` after starting Uvicorn. The page is served by FastAPI and calls the existing API endpoints directly. It includes station lookup, train search, passenger signup/login, profile-aware session handling, booking, booking history, PNR lookup, cancellation, and an admin-only train management panel. The access token is kept in `sessionStorage` for the current browser tab session and is sent as a Bearer token for protected requests. Password reset tokens are development-only and are returned by the API simulation; use `/docs` to complete reset with `POST /auth/reset-password`.

## Main endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/auth/signup` | Public | Register passenger |
| POST | `/auth/login` | Public | Get access JWT |
| POST | `/auth/logout` | Authenticated | Revoke current token |
| GET | `/users/me` | Authenticated | Own profile |
| POST | `/auth/forgot-password` | Public | Create one-use reset token (dev simulation) |
| POST | `/auth/reset-password` | Public | Reset password |
| GET | `/stations` | Public | List stations |
| POST | `/admin/stations` | Admin | Add station |
| POST | `/admin/trains` | Admin | Add train and route |
| GET | `/admin/trains` | Admin | List trains |
| PATCH | `/admin/trains/{train_id}` | Admin | Update train data |
| POST | `/admin/trains/{train_id}/deactivate` | Admin | Deactivate train |
| GET | `/trains/search?source=NDLS&destination=CNB&journey_date=YYYY-MM-DD` | Public | Search trains and seats |
| POST | `/bookings` | Authenticated | Book seats and receive PNR |
| GET | `/bookings` | Authenticated | Own booking history |
| GET | `/bookings/{pnr}` | Authenticated | Read own booking |
| POST | `/bookings/{pnr}/cancel` | Authenticated | Cancel own confirmed booking |
| GET | `/admin/inventory/{train_id}?journey_date=YYYY-MM-DD` | Admin | Inspect seat inventory |

Use Swagger's **Authorize** button with `Bearer <access_token>` after login. Admin endpoints require the seeded admin account.

## Example workflow

1. Login as the local admin at `/auth/login`.
2. Search stations using `GET /stations` to get station IDs.
3. Add a train with `POST /admin/trains` (example demo train already exists: RC1201, New Delhi NDLS to Kanpur Central CNB).
4. Sign up a passenger, log in, and copy the access token into Swagger Authorize.
5. Search using a future date, then `POST /bookings` with `train_id`, `journey_date`, `passenger_name`, and `seats`.
6. Save the returned PNR; inspect with `GET /bookings/{pnr}` and cancel with `POST /bookings/{pnr}/cancel`.

## Tests

```powershell
python -m pytest -v
```

Tests use a temporary in-memory SQLite database and do not rely on real railway data. The booking implementation uses a conditional SQL update to atomically decrement inventory only when enough seats remain; cancellation conditionally changes status before restoring inventory. SQLite serializes writes, and the update conditions prevent the common overbooking/double-release races. For a multi-instance production deployment, use a database with robust row-level locking/transaction semantics, run concurrency/load tests, and add operational controls.

## Screenshots

The `screenshots/` folder is provided for screenshots captured from your own running instance. Capture these in `/docs` after executing each workflow and save them here:

- `01-signup-login.png`
- `02-failed-login-unauthorized.png`
- `03-forgot-reset-password.png`
- `04-admin-add-train.png`
- `05-train-search-seats.png`
- `06-booking-pnr.png`
- `07-view-cancel-booking.png`
- `08-tests-passed.png`

Then include them in this README using links such as `![Signup and login](screenshots/01-signup-login.png)`. **No fabricated screenshots are included**: capture them from your own application. Never capture passwords, JWTs, reset tokens or secrets. Redact sensitive values before committing screenshots.

## Security and limitations

- Store secrets only in `.env`, which is ignored by Git. `.env.example` contains placeholders/demo values only.
- Logout revokes the current JWT by storing its `jti` until token expiry; clients should also discard their token.
- Reset tokens are hashed in the database, expire, and are marked used on success. The development response exposes the token solely to simulate email delivery; replace with an email provider before deployment.
- Payments are simulated. No IRCTC integration, real ticketing, real email, refunds, waitlists, seat-map selection or production deployment hardening is included.
- Inventory is tracked per train and journey date, not per individually selected seat number.
